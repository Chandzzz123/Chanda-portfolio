CHANDA BWALYA - CONFERENCE PORTFOLIO

FOR IPAD:
1. Save Chanda_Bwalya_iPad_Portfolio.html to Files.
2. Tap it, choose Share > Open in Safari if available (or preview in Files).
3. For the most reliable CV viewing, open Chanda_Bwalya_Complete_Academic_CV.pdf separately in Files.
4. The iPad HTML is a self-contained offline preview with the headshot and CV embedded; some iPad viewers restrict embedded PDF downloads.

TO SHARE WITH CONFERENCE ATTENDEES:
Publish the regular index.html plus chanda_headshot.jpg and Chanda_Bwalya_Complete_Academic_CV.pdf on GitHub Pages. Your local file link is not public. After publishing, create a QR code from the public URL.

The academic CV reflects supplied resume details and requested updates. Verify dates and honors before public sharing.
