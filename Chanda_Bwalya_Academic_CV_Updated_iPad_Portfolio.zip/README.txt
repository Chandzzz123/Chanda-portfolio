CHANDA BWALYA CONFERENCE PORTFOLIO

1. Open index.html to preview the portfolio.
2. Verify your preferred email address: your uploaded resumes contain two different addresses.
3. Add your LinkedIn profile link, if desired.
4. Confirm all titles and details; obtain PI permission before posting a conference poster.
5. Upload index.html and Chanda_Bwalya_Academic_CV.pdf to a website host.
6. Once you have a public URL, generate a QR code for that exact URL and replace the placeholder on networking_card.html.
7. Print the card at 100% scale (3.5 x 2 inches).

Note: the linked academic CV is a copy of your supplied SACNAS resume; it has not been rewritten.
